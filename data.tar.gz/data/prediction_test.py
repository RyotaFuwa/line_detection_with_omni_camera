import matplotlib.pyplot as plt
import cv2
from keras.models import load_model

model_ = load_model('model_prottype1.h5')

def predict(num, model=model_):
    img = cv2.imread('image-' + str(num) + '-original.jpg')
    out = model.predict(img.reshape((1, 480, 480, 3)))
    plt.subplot(1, 2, 1)
    plt.imshow(img)
    plt.subplot(1, 2, 2)
    plt.imshow(out[0, :, :, 0], 'gray')
    plt.show()
    return out[0, :, :, 0]



